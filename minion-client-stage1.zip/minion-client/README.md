# Minion Client (Stage 1)  -  Minecraft 1.21.11, Fabric, Yarn

Implemented so far
- Module framework: categories, typed settings (toggle, slider, mode, color), per-module keybinds, crash isolation
- ClickGUI (Right Shift): collapsible categories, search, master list, descriptions, ON/OFF state,
  settings, keybind editing, profile switcher (< name > +), accent/opacity/dim/spacing options
- Config profiles saved to config/minionclient/profiles/<name>.json (bad files are moved aside, never crash)
- Block ESP (Visuals): pick blocks in a searchable picker, per-block colors, filled/outline/both, range, fade, max highlights; drawn through walls
- Sus Chunk Finder: amethyst geode scan + chat coordinates (no in-world highlight until the render stage)

Build
  Easiest: generate a template at https://fabricmc.net/develop/template (1.21.11, Yarn, Java 21),
  then copy this project's src/ folder over the template's src/ and run  ./gradlew build
  The jar appears in build/libs/. Put it in .minecraft/mods together with Fabric API.
  (This zip has no gradle wrapper jar; or run `gradle wrapper --gradle-version 9.2.1` yourself.)

NOT yet compiled or tested. Paste any compile errors back and they will be fixed before Stage 2.

Build without installing anything (works from a phone browser)
  1. Create a free GitHub account and a new repository.
  2. Upload everything from this folder (including the hidden .github folder).
  3. Open the Actions tab -> "Build Minion Client" -> wait until it is green.
  4. Download the artifact "minion-client-jar" (zip containing the .jar). Use the jar WITHOUT "-sources".
  5. Put that .jar in .minecraft/mods together with Fabric API (Fabric Loader, Minecraft 1.21.11).
