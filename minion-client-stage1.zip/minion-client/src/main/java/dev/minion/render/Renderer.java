package dev.minion.render;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat;
import dev.minion.MinionClient;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.MappableRingBuffer;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BuiltBuffer;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.system.MemoryUtil;

import java.util.OptionalDouble;
import java.util.OptionalInt;

/**
 * Shared world renderer: modules queue boxes in onRender(); everything is drawn in one pass through walls.
 * Based on the Fabric docs "Rendering in the World" page for 1.21.11, translated to Yarn names.
 */
public final class Renderer {
    public static final Renderer INSTANCE = new Renderer();

    private static final RenderPipeline THROUGH_WALLS = RenderPipelines.register(
            RenderPipeline.builder(RenderPipelines.DEBUG_FILLED_SNIPPET)
                    .withLocation(Identifier.of("minionclient", "pipeline/filled_through_walls"))
                    .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                    .build());

    private static final Vector4f COLOR_MODULATOR = new Vector4f(1f, 1f, 1f, 1f);
    private static final Vector3f MODEL_OFFSET = new Vector3f();
    private static final Matrix4f TEXTURE_MATRIX = new Matrix4f();

    private final BufferAllocator allocator = new BufferAllocator(1 << 20);
    private MappableRingBuffer vertexBuffer;
    private BufferBuilder buffer;
    private Matrix4f matrix;
    private Vec3d cam = Vec3d.ZERO;
    private boolean broken;

    private Renderer() {}

    public void init() {
        WorldRenderEvents.BEFORE_TRANSLUCENT.register(this::onWorldRender);
        ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> close());
    }

    // ------------------------------------------------------------ public drawing API (call from Module.onRender)

    public void filledBox(double x0, double y0, double z0, double x1, double y1, double z1, int argb) {
        if (broken) return;
        BufferBuilder b = ensureBuffer();
        float minX = (float) (x0 - cam.x), minY = (float) (y0 - cam.y), minZ = (float) (z0 - cam.z);
        float maxX = (float) (x1 - cam.x), maxY = (float) (y1 - cam.y), maxZ = (float) (z1 - cam.z);
        int a = argb >>> 24, r = (argb >> 16) & 255, g = (argb >> 8) & 255, bl = argb & 255;

        // front (+z)
        v(b, minX, minY, maxZ, r, g, bl, a); v(b, maxX, minY, maxZ, r, g, bl, a);
        v(b, maxX, maxY, maxZ, r, g, bl, a); v(b, minX, maxY, maxZ, r, g, bl, a);
        // back (-z)
        v(b, maxX, minY, minZ, r, g, bl, a); v(b, minX, minY, minZ, r, g, bl, a);
        v(b, minX, maxY, minZ, r, g, bl, a); v(b, maxX, maxY, minZ, r, g, bl, a);
        // left (-x)
        v(b, minX, minY, minZ, r, g, bl, a); v(b, minX, minY, maxZ, r, g, bl, a);
        v(b, minX, maxY, maxZ, r, g, bl, a); v(b, minX, maxY, minZ, r, g, bl, a);
        // right (+x)
        v(b, maxX, minY, maxZ, r, g, bl, a); v(b, maxX, minY, minZ, r, g, bl, a);
        v(b, maxX, maxY, minZ, r, g, bl, a); v(b, maxX, maxY, maxZ, r, g, bl, a);
        // top
        v(b, minX, maxY, maxZ, r, g, bl, a); v(b, maxX, maxY, maxZ, r, g, bl, a);
        v(b, maxX, maxY, minZ, r, g, bl, a); v(b, minX, maxY, minZ, r, g, bl, a);
        // bottom
        v(b, minX, minY, minZ, r, g, bl, a); v(b, maxX, minY, minZ, r, g, bl, a);
        v(b, maxX, minY, maxZ, r, g, bl, a); v(b, minX, minY, maxZ, r, g, bl, a);
    }

    /** Outline built from 12 thin boxes, so thickness is configurable. */
    public void outlineBox(double x0, double y0, double z0, double x1, double y1, double z1, double t, int argb) {
        for (double y : new double[]{y0, y1 - t})
            for (double z : new double[]{z0, z1 - t})
                filledBox(x0, y, z, x1, y + t, z + t, argb);
        for (double x : new double[]{x0, x1 - t})
            for (double z : new double[]{z0, z1 - t})
                filledBox(x, y0, z, x + t, y1, z + t, argb);
        for (double x : new double[]{x0, x1 - t})
            for (double y : new double[]{y0, y1 - t})
                filledBox(x, y, z0, x + t, y + t, z1, argb);
    }

    public Vec3d cameraPos() { return cam; }

    public static int withAlpha(int argb, int alpha) {
        return (Math.max(0, Math.min(255, alpha)) << 24) | (argb & 0xFFFFFF);
    }

    // ------------------------------------------------------------ internals

    private static void v(BufferBuilder b, float x, float y, float z, int r, int g, int bl, int a) {
        b.vertex(matrix(b), x, y, z).color(r, g, bl, a);
    }

    // The matrix is passed via a thread-confined static so v() stays short.
    private static Matrix4f currentMatrix;
    private static Matrix4f matrix(BufferBuilder ignored) { return currentMatrix; }

    private BufferBuilder ensureBuffer() {
        if (buffer == null)
            buffer = new BufferBuilder(allocator, THROUGH_WALLS.getVertexFormatMode(), THROUGH_WALLS.getVertexFormat());
        return buffer;
    }

    private void onWorldRender(WorldRenderContext context) {
        if (broken) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return;
        try {
            cam = context.worldState().cameraRenderState.pos;
            matrix = context.matrices().peek().getPositionMatrix();
            currentMatrix = matrix;
            buffer = null;
            MinionClient.modules().render(this);
            if (buffer != null) drawBuffer(mc);
        } catch (Throwable t) {
            MinionClient.LOG.error("World renderer failed; disabling Minion rendering for this session", t);
            broken = true;
            buffer = null;
        }
    }

    private void drawBuffer(MinecraftClient client) {
        BuiltBuffer built = buffer.end();
        buffer = null;
        BuiltBuffer.DrawParameters params = built.getDrawParameters();
        VertexFormat format = params.format();

        // upload vertices
        int size = params.vertexCount() * format.getVertexSize();
        if (vertexBuffer == null || vertexBuffer.size() < size) {
            if (vertexBuffer != null) vertexBuffer.close();
            vertexBuffer = new MappableRingBuffer(() -> "minionclient esp",
                    GpuBuffer.USAGE_VERTEX | GpuBuffer.USAGE_MAP_WRITE, size);
        }
        CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
        try (GpuBuffer.MappedView view = encoder.mapBuffer(
                vertexBuffer.currentBuffer().slice(0, built.getBuffer().remaining()), false, true)) {
            MemoryUtil.memCopy(built.getBuffer(), view.data());
        }
        GpuBuffer vertices = vertexBuffer.currentBuffer();

        // quads use the shared sequential index buffer (no translucency sorting)
        var shape = RenderSystem.getSequentialBuffer(THROUGH_WALLS.getVertexFormatMode());
        GpuBuffer indices = shape.getIndexBuffer(params.indexCount());
        var indexType = shape.getIndexType();

        GpuBufferSlice transforms = RenderSystem.getDynamicUniforms()
                .writeTransform(RenderSystem.getModelViewMatrix(), COLOR_MODULATOR, MODEL_OFFSET, TEXTURE_MATRIX);

        try (RenderPass pass = RenderSystem.getDevice().createCommandEncoder().createRenderPass(
                () -> "minionclient esp draw",
                client.getFramebuffer().getColorAttachmentView(), OptionalInt.empty(),
                client.getFramebuffer().getDepthAttachmentView(), OptionalDouble.empty())) {
            pass.setPipeline(THROUGH_WALLS);
            RenderSystem.bindDefaultUniforms(pass);
            pass.setUniform("DynamicTransforms", transforms);
            pass.setVertexBuffer(0, vertices);
            pass.setIndexBuffer(indices, indexType);
            pass.drawIndexed(0, 0, params.indexCount(), 1);
        }

        built.close();
        vertexBuffer.rotate();
    }

    private void close() {
        allocator.close();
        if (vertexBuffer != null) {
            vertexBuffer.close();
            vertexBuffer = null;
        }
    }
}
