package dev.minion.gui;

import dev.minion.MinionClient;
import dev.minion.config.ConfigManager;
import dev.minion.core.Category;
import dev.minion.core.Module;
import dev.minion.core.setting.*;
import dev.minion.modules.ClickGuiModule;
import dev.minion.util.Keys;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.*;
import java.util.function.DoubleConsumer;
import java.util.function.IntConsumer;

/** Collapsible-category module list with search, master list, per-module settings and keybind editing. */
public class ClickGuiScreen extends Screen {
    private static final Set<Category> COLLAPSED = EnumSet.noneOf(Category.class);
    private static final Set<Module> EXPANDED = new HashSet<>();

    private static final int ROW_BG = 0xFF1A1A24;
    private static final int ROW_HOVER = 0xFF262632;
    private static final int HEADER_BG = 0xFF12121A;
    private static final int MUTED = 0xFF8A8A9A;

    private final Map<Module, Float> anim = new HashMap<>();
    private final List<Region> regions = new ArrayList<>();
    private String search = "";
    private boolean masterList;
    private float scroll, scrollTarget;
    private int listTop, listBottom, contentHeight;
    private Module binding;
    private Region dragging;
    private String hint = "";

    private static final class Region {
        final int x, y, w, h;
        final boolean clip;
        final IntConsumer click;
        final DoubleConsumer drag;

        Region(int x, int y, int w, int h, boolean clip, IntConsumer click, DoubleConsumer drag) {
            this.x = x; this.y = y; this.w = w; this.h = h;
            this.clip = clip; this.click = click; this.drag = drag;
        }

        boolean hit(double mx, double my) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    }

    public ClickGuiScreen() {
        super(Text.literal("Minion Client"));
    }

    @Override public boolean shouldPause() { return false; }

    @Override
    public void close() {
        ConfigManager.save();
        super.close();
    }

    // ------------------------------------------------------------------ render

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        ClickGuiModule g = ClickGuiModule.INSTANCE;
        regions.clear();
        hint = "";
        int rowH = g.rowHeight.getInt();
        int gap = g.spacing.getInt();
        int accent = g.accent.get();

        ctx.fill(0, 0, width, height, g.dim.getInt() << 24);

        int pw = Math.min(320, width - 16);
        int px = (width - pw) / 2;
        int top = 12;
        int bottom = height - 12;
        ctx.fill(px - 6, top - 6, px + pw + 6, bottom + 6, (g.opacity.getInt() << 24) | 0x0E0E14);
        ctx.fill(px - 6, top - 6, px + pw + 6, top - 4, accent);

        int y = top;
        ctx.drawTextWithShadow(textRenderer, "Minion Client", px + 2, y + (rowH - 8) / 2, accent);
        drawProfileControls(ctx, px, y, pw, rowH, mx, my, accent);
        y += rowH + gap;

        drawSearchRow(ctx, px, y, pw, rowH, mx, my, accent);
        y += rowH + gap;

        listTop = y;
        listBottom = bottom - rowH - gap;

        // scrolling
        int viewport = listBottom - listTop;
        float maxScroll = Math.max(0, contentHeight - viewport);
        scrollTarget = Math.max(0, Math.min(maxScroll, scrollTarget));
        scroll += (scrollTarget - scroll) * (g.animations.get() ? 0.3f : 1f);
        if (Math.abs(scrollTarget - scroll) < 0.5f) scroll = scrollTarget;

        ctx.enableScissor(px - 2, listTop, px + pw + 2, listBottom);
        int startY = listTop - Math.round(scroll);
        int cy = startY;
        String q = search.toLowerCase(Locale.ROOT).trim();

        if (!q.isEmpty() || masterList) {
            List<Module> list = new ArrayList<>();
            for (Module m : MinionClient.modules().all()) if (q.isEmpty() || matches(m, q)) list.add(m);
            list.sort(Comparator.<Module>comparingInt(m -> m.category.ordinal()).thenComparing(m -> m.name));
            for (Module m : list) cy += drawModule(ctx, m, px, cy, pw, rowH, gap, mx, my, accent, true);
            if (list.isEmpty())
                ctx.drawTextWithShadow(textRenderer, "No modules found", px + 8, cy + 4, MUTED);
        } else {
            for (Category c : Category.values()) {
                List<Module> mods = MinionClient.modules().in(c);
                cy += drawCategory(ctx, c, mods.size(), px, cy, pw, rowH, gap, mx, my, accent);
                if (COLLAPSED.contains(c)) continue;
                if (mods.isEmpty()) {
                    ctx.drawTextWithShadow(textRenderer, "No modules yet", px + 14, cy + (rowH - 8) / 2, 0xFF55556A);
                    cy += rowH + gap;
                }
                for (Module m : mods) cy += drawModule(ctx, m, px, cy, pw, rowH, gap, mx, my, accent, false);
            }
        }
        contentHeight = cy - startY;
        ctx.disableScissor();

        // footer / hint
        ctx.fill(px, bottom - rowH, px + pw, bottom, HEADER_BG);
        String footer = hint.isEmpty()
                ? "Left-click: toggle  |  Right-click: settings  |  Right Shift: close" : hint;
        ctx.drawTextWithShadow(textRenderer, textRenderer.trimToWidth(footer, pw - 12),
                px + 6, bottom - rowH + (rowH - 8) / 2, 0xFFA0A0B0);
    }

    private void drawProfileControls(DrawContext ctx, int px, int y, int pw, int rowH, int mx, int my, int accent) {
        String name = ConfigManager.active();
        int aw = rowH;
        int boxW = Math.max(60, textRenderer.getWidth(name) + 12);
        int plusX = px + pw - aw;
        int nextX = plusX - 2 - aw;
        int boxX = nextX - 2 - boxW;
        int prevX = boxX - 2 - aw;

        button(ctx, prevX, y, aw, rowH, "<", mx, my);
        regions.add(new Region(prevX, y, aw, rowH, false, b -> ConfigManager.cycleProfile(-1), null));

        ctx.fill(boxX, y, boxX + boxW, y + rowH, ROW_BG);
        ctx.drawTextWithShadow(textRenderer, name,
                boxX + (boxW - textRenderer.getWidth(name)) / 2, y + (rowH - 8) / 2, 0xFFFFFFFF);
        if (inside(mx, my, boxX, y, boxW, rowH)) hint = "Active profile. Use < > to switch, + to create a new one.";

        button(ctx, nextX, y, aw, rowH, ">", mx, my);
        regions.add(new Region(nextX, y, aw, rowH, false, b -> ConfigManager.cycleProfile(1), null));

        button(ctx, plusX, y, aw, rowH, "+", mx, my);
        regions.add(new Region(plusX, y, aw, rowH, false, b -> ConfigManager.createProfile(), null));
    }

    private void drawSearchRow(DrawContext ctx, int px, int y, int pw, int rowH, int mx, int my, int accent) {
        int btnW = 62;
        ctx.fill(px, y, px + pw - btnW - 4, y + rowH, ROW_BG);
        boolean empty = search.isEmpty();
        String shown = empty ? "Search modules..."
                : search + ((System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
        ctx.drawTextWithShadow(textRenderer, shown, px + 6, y + (rowH - 8) / 2, empty ? 0xFF707080 : 0xFFFFFFFF);

        int bx = px + pw - btnW;
        boolean hover = inside(mx, my, bx, y, btnW, rowH);
        ctx.fill(bx, y, bx + btnW, y + rowH, masterList ? (accent & 0xFFFFFF) | 0x99000000 : hover ? ROW_HOVER : ROW_BG);
        String label = "All modules";
        label = textRenderer.trimToWidth(label, btnW - 4);
        ctx.drawTextWithShadow(textRenderer, label, bx + (btnW - textRenderer.getWidth(label)) / 2,
                y + (rowH - 8) / 2, 0xFFFFFFFF);
        if (hover) hint = "Master list: show every module in one flat list.";
        regions.add(new Region(bx, y, btnW, rowH, false, b -> { masterList = !masterList; scrollTarget = 0; }, null));
    }

    private int drawCategory(DrawContext ctx, Category c, int count, int x, int y, int w, int rowH, int gap,
                             int mx, int my, int accent) {
        boolean col = COLLAPSED.contains(c);
        boolean hover = inList(mx, my) && inside(mx, my, x, y, w, rowH);
        ctx.fill(x, y, x + w, y + rowH, hover ? ROW_HOVER : HEADER_BG);
        int bs = rowH - 6;
        ctx.fill(x + 3, y + 3, x + 3 + bs, y + 3 + bs, accent);
        ctx.drawTextWithShadow(textRenderer, c.icon,
                x + 3 + (bs - textRenderer.getWidth(c.icon)) / 2, y + (rowH - 8) / 2, 0xFF101018);
        ctx.drawTextWithShadow(textRenderer, c.label, x + bs + 9, y + (rowH - 8) / 2, 0xFFFFFFFF);
        String right = count + "  " + (col ? "+" : "-");
        ctx.drawTextWithShadow(textRenderer, right, x + w - textRenderer.getWidth(right) - 6,
                y + (rowH - 8) / 2, MUTED);
        if (hover) hint = "Click to " + (col ? "expand " : "collapse ") + c.label;
        regions.add(new Region(x, y, w, rowH, true, b -> { if (col) COLLAPSED.remove(c); else COLLAPSED.add(c); }, null));
        return rowH + gap;
    }

    private int drawModule(DrawContext ctx, Module m, int x, int y, int w, int rowH, int gap,
                           int mx, int my, int accent, boolean showCategory) {
        ClickGuiModule g = ClickGuiModule.INSTANCE;
        boolean exp = EXPANDED.contains(m);
        float target = exp ? 1f : 0f;
        float a = anim.getOrDefault(m, target);
        a = g.animations.get() ? a + (target - a) * 0.25f : target;
        if (Math.abs(target - a) < 0.01f) a = target;
        anim.put(m, a);

        int rows = 1 + m.getSettings().size();
        int extra = Math.round(rows * rowH * a);
        boolean hover = inList(mx, my) && inside(mx, my, x, y, w, rowH);
        boolean on = m.isEnabled();
        int ty = y + (rowH - 8) / 2;

        ctx.fill(x, y, x + w, y + rowH, hover ? ROW_HOVER : ROW_BG);
        if (m.isToggleable()) ctx.fill(x, y, x + 3, y + rowH, on ? accent : 0xFF3A3A48);
        ctx.drawTextWithShadow(textRenderer, m.name, x + 9, ty, on || !m.isToggleable() ? 0xFFFFFFFF : 0xFFB0B0C0);
        int nameW = textRenderer.getWidth(m.name);
        if (showCategory)
            ctx.drawTextWithShadow(textRenderer, m.category.label, x + 9 + nameW + 6, ty, 0xFF55556A);

        String state = m.isToggleable() ? (on ? "ON" : "OFF") : "";
        String keyPart = m.getKey() >= 0 ? "[" + Keys.name(m.getKey()) + "] " : "";
        String right = keyPart + state + (state.isEmpty() ? "" : " ") + (exp ? "v" : ">");
        int rw = textRenderer.getWidth(right);
        ctx.drawTextWithShadow(textRenderer, right, x + w - rw - 6, ty, on ? accent : MUTED);

        if (hover) hint = m.description;
        regions.add(new Region(x, y, w, rowH, true, btn -> {
            if (btn == 0 && m.isToggleable()) m.setEnabled(!m.isEnabled());
            else toggleExpand(m);
        }, null));

        if (a > 0.02f) {
            int limit = y + rowH + extra;
            int sx = x + 6, sw = w - 6;
            int ry = y + rowH;

            // keybind row
            if (ry + rowH <= limit) {
                boolean bh = inList(mx, my) && inside(mx, my, sx, ry, sw, rowH);
                ctx.fill(sx, ry, sx + sw, ry + rowH - 1, bh ? ROW_HOVER : 0xFF15151E);
                ctx.drawTextWithShadow(textRenderer, "Keybind", sx + 6, ry + (rowH - 8) / 2, 0xFFD0D0E0);
                String kv = binding == m ? "Press a key..." : Keys.name(m.getKey());
                ctx.drawTextWithShadow(textRenderer, kv, sx + sw - textRenderer.getWidth(kv) - 6,
                        ry + (rowH - 8) / 2, binding == m ? accent : MUTED);
                if (bh) hint = "Left-click: set keybind (Esc cancels, Backspace clears). Right-click: clear.";
                regions.add(new Region(sx, ry, sw, rowH, true, btn -> {
                    if (btn == 0) binding = m; else m.setKey(-1);
                }, null));
            }
            ry += rowH;

            for (Setting<?> s : m.getSettings()) {
                if (ry + rowH <= limit) drawSetting(ctx, s, sx, ry, sw, rowH, mx, my, accent);
                ry += rowH;
            }
        }
        return rowH + extra + gap;
    }

    private void drawSetting(DrawContext ctx, Setting<?> s, int x, int y, int w, int rowH, int mx, int my, int accent) {
        boolean hover = inList(mx, my) && inside(mx, my, x, y, w, rowH);
        int ty = y + (rowH - 8) / 2;
        ctx.fill(x, y, x + w, y + rowH - 1, hover ? ROW_HOVER : 0xFF15151E);
        if (hover) hint = s.description;

        String value;
        int valueColor = MUTED;
        if (s instanceof BoolSetting b) {
            value = b.get() ? "ON" : "OFF";
            valueColor = b.get() ? accent : MUTED;
            regions.add(new Region(x, y, w, rowH, true, btn -> b.toggle(), null));
        } else if (s instanceof NumberSetting n) {
            int fillW = (int) ((w) * Math.max(0, Math.min(1, n.fraction())));
            ctx.fill(x, y, x + fillW, y + rowH - 1, (accent & 0xFFFFFF) | 0x55000000);
            value = n.step >= 1 ? String.valueOf(n.getInt()) : String.format(Locale.ROOT, "%.2f", n.getDouble());
            valueColor = 0xFFFFFFFF;
            regions.add(new Region(x, y, w, rowH, true, null, px -> n.setFromFraction((px - x) / (double) w)));
        } else if (s instanceof ModeSetting md) {
            value = md.get();
            valueColor = 0xFFFFFFFF;
            regions.add(new Region(x, y, w, rowH, true, btn -> md.cycle(btn == 1 ? -1 : 1), null));
        } else if (s instanceof ColorSetting c) {
            value = "";
            ctx.fill(x + w - 22, y + 3, x + w - 6, y + rowH - 4, 0xFFFFFFFF);
            ctx.fill(x + w - 21, y + 4, x + w - 7, y + rowH - 5, c.get());
            regions.add(new Region(x, y, w, rowH, true, btn -> c.cycle(btn == 1 ? -1 : 1), null));
        } else if (s instanceof BlockListSetting bl) {
            value = bl.get().size() + " selected  >";
            valueColor = 0xFFFFFFFF;
            regions.add(new Region(x, y, w, rowH, true,
                    btn -> net.minecraft.client.MinecraftClient.getInstance().setScreen(new BlockPickerScreen(this, bl)), null));
        } else {
            value = String.valueOf(s.get());
        }

        ctx.drawTextWithShadow(textRenderer, s.name, x + 6, ty, 0xFFD0D0E0);
        if (!value.isEmpty())
            ctx.drawTextWithShadow(textRenderer, value, x + w - textRenderer.getWidth(value) - 6, ty, valueColor);
    }

    private void button(DrawContext ctx, int x, int y, int w, int h, String label, int mx, int my) {
        ctx.fill(x, y, x + w, y + h, inside(mx, my, x, y, w, h) ? ROW_HOVER : ROW_BG);
        ctx.drawTextWithShadow(textRenderer, label, x + (w - textRenderer.getWidth(label)) / 2,
                y + (h - 8) / 2, 0xFFFFFFFF);
    }

    // ------------------------------------------------------------------ helpers

    private static void toggleExpand(Module m) {
        if (!EXPANDED.remove(m)) EXPANDED.add(m);
    }

    private static boolean matches(Module m, String q) {
        return m.name.toLowerCase(Locale.ROOT).contains(q)
                || m.description.toLowerCase(Locale.ROOT).contains(q)
                || m.category.label.toLowerCase(Locale.ROOT).contains(q);
    }

    private static boolean inside(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private boolean inList(int mx, int my) { return my >= listTop && my <= listBottom; }

    // ------------------------------------------------------------------ input

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        int btn = click.button();
        binding = null;
        for (int i = regions.size() - 1; i >= 0; i--) {
            Region r = regions.get(i);
            if (!r.hit(mx, my)) continue;
            if (r.clip && (my < listTop || my > listBottom)) continue;
            if (r.click != null) r.click.accept(btn);
            if (r.drag != null && btn == 0) {
                dragging = r;
                r.drag.accept(mx);
            }
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (dragging != null && dragging.drag != null) {
            dragging.drag.accept(click.x());
            return true;
        }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        dragging = null;
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scrollTarget -= (float) (verticalAmount * ClickGuiModule.INSTANCE.rowHeight.getInt() * 2);
        return true;
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int k = input.getKeycode();
        if (binding != null) {
            if (k == GLFW.GLFW_KEY_BACKSPACE || k == GLFW.GLFW_KEY_DELETE) binding.setKey(-1);
            else if (k != GLFW.GLFW_KEY_ESCAPE) binding.setKey(k);
            binding = null;
            return true;
        }
        if (k == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        if (k == GLFW.GLFW_KEY_BACKSPACE && !search.isEmpty()) {
            search = search.substring(0, search.length() - 1);
            scrollTarget = 0;
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public boolean charTyped(CharInput input) {
        if (binding != null) return true;
        if (input.isValidChar() && search.length() < 32) {
            search += input.asString();
            scrollTarget = 0;
            return true;
        }
        return super.charTyped(input);
    }
}
