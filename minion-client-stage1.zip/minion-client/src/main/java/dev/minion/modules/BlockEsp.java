package dev.minion.modules;

import dev.minion.core.Category;
import dev.minion.core.Module;
import dev.minion.core.setting.*;
import dev.minion.render.Renderer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.ChunkStatus;
import net.minecraft.world.chunk.WorldChunk;

import java.util.*;

/** Highlights the blocks you pick (through walls). Pick blocks by clicking the "Blocks" row. */
public class BlockEsp extends Module {
    private record Found(int x, int y, int z, int color) {}

    private static final int MAX_PER_CHUNK = 4096;
    private static final int SCANS_PER_TICK = 3;

    public final BlockListSetting blocks = add(new BlockListSetting("Blocks",
            "Click to open the block picker. Left-click a block to add/remove it, right-click to change its color.",
            defaults()));
    public final NumberSetting range = add(new NumberSetting("Range", "Max distance in blocks.", 64, 16, 128, 8));
    public final NumberSetting maxBlocks = add(new NumberSetting("Max highlights",
            "Most blocks drawn at once (nearest first). Lower = faster.", 500, 50, 3000, 50));
    public final ModeSetting style = add(new ModeSetting("Style", "Filled, outline, or both.", "Both",
            "Filled", "Outline", "Both"));
    public final NumberSetting fillOpacity = add(new NumberSetting("Fill opacity", "Opacity of the filled box.", 60, 10, 200, 5));
    public final NumberSetting thickness = add(new NumberSetting("Outline thickness", "Outline width in blocks.", 0.03, 0.01, 0.1, 0.01));
    public final BoolSetting fade = add(new BoolSetting("Distance fade", "Fade highlights out with distance.", true));
    public final NumberSetting rescan = add(new NumberSetting("Rescan interval", "Seconds between rescans (catches mined/placed blocks).", 5, 1, 30, 1));

    private final Map<Block, Integer> targets = new HashMap<>();
    private final Map<ChunkPos, List<Found>> found = new HashMap<>();
    private final ArrayDeque<ChunkPos> queue = new ArrayDeque<>();
    private int targetsVersion = -1;
    private int timer;

    public BlockEsp() {
        super("Block ESP", "Highlights chosen blocks through walls.", Category.VISUALS);
        ClientChunkEvents.CHUNK_LOAD.register((world, chunk) -> { if (isEnabled()) queue.add(chunk.getPos()); });
        ClientChunkEvents.CHUNK_UNLOAD.register((world, chunk) -> found.remove(chunk.getPos()));
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> { found.clear(); queue.clear(); });
    }

    private static Map<String, Integer> defaults() {
        Map<String, Integer> m = new LinkedHashMap<>();
        m.put("minecraft:diamond_ore", ColorSetting.PALETTE[1]);
        m.put("minecraft:deepslate_diamond_ore", ColorSetting.PALETTE[1]);
        m.put("minecraft:ancient_debris", ColorSetting.PALETTE[3]);
        m.put("minecraft:budding_amethyst_block", ColorSetting.PALETTE[0]);
        return m;
    }

    @Override
    protected void onEnable(MinecraftClient mc) { rebuild(mc); }

    @Override
    protected void onDisable(MinecraftClient mc) {
        found.clear();
        queue.clear();
    }

    private void refreshTargets() {
        targets.clear();
        for (Map.Entry<String, Integer> e : blocks.get().entrySet()) {
            Identifier id = Identifier.tryParse(e.getKey());
            if (id != null && Registries.BLOCK.containsId(id)) targets.put(Registries.BLOCK.get(id), e.getValue());
        }
        targetsVersion = blocks.version;
    }

    private void rebuild(MinecraftClient mc) {
        refreshTargets();
        found.clear();
        queue.clear();
        queueAround(mc);
    }

    private void queueAround(MinecraftClient mc) {
        if (mc.player == null) return;
        int r = Math.min(mc.options.getClampedViewDistance(), (int) Math.ceil(range.getDouble() / 16.0) + 1);
        ChunkPos c = mc.player.getChunkPos();
        for (int dx = -r; dx <= r; dx++)
            for (int dz = -r; dz <= r; dz++) queue.add(new ChunkPos(c.x + dx, c.z + dz));
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.world == null) return;
        if (targetsVersion != blocks.version) rebuild(mc);
        if (++timer >= rescan.getInt() * 20) {
            timer = 0;
            if (queue.isEmpty()) queueAround(mc);
        }
        for (int i = 0; i < SCANS_PER_TICK && !queue.isEmpty(); i++) {
            ChunkPos pos = queue.poll();
            if (!(mc.world.getChunk(pos.x, pos.z, ChunkStatus.FULL, false) instanceof WorldChunk chunk)) continue;
            List<Found> list = scan(chunk);
            if (list.isEmpty()) found.remove(pos); else found.put(pos, list);
        }
    }

    private List<Found> scan(WorldChunk chunk) {
        List<Found> out = new ArrayList<>();
        if (targets.isEmpty()) return out;
        ChunkSection[] sections = chunk.getSectionArray();
        int bottom = chunk.getBottomY();
        int sx = chunk.getPos().getStartX(), sz = chunk.getPos().getStartZ();
        for (int i = 0; i < sections.length; i++) {
            ChunkSection sec = sections[i];
            if (sec == null || sec.isEmpty() || !sec.hasAny(s -> targets.containsKey(s.getBlock()))) continue;
            int baseY = bottom + i * 16;
            for (int x = 0; x < 16; x++)
                for (int y = 0; y < 16; y++)
                    for (int z = 0; z < 16; z++) {
                        Integer color = targets.get(sec.getBlockState(x, y, z).getBlock());
                        if (color == null) continue;
                        out.add(new Found(sx + x, baseY + y, sz + z, color));
                        if (out.size() >= MAX_PER_CHUNK) return out;
                    }
        }
        return out;
    }

    @Override
    public void onRender(Renderer r) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || found.isEmpty()) return;
        double px = mc.player.getX(), py = mc.player.getY(), pz = mc.player.getZ();
        double rng = range.getDouble(), r2 = rng * rng;

        record Cand(Found f, double d2) {}
        List<Cand> cands = new ArrayList<>();
        for (List<Found> list : found.values())
            for (Found f : list) {
                double dx = f.x() + 0.5 - px, dy = f.y() + 0.5 - py, dz = f.z() + 0.5 - pz;
                double d2 = dx * dx + dy * dy + dz * dz;
                if (d2 <= r2) cands.add(new Cand(f, d2));
            }
        int max = maxBlocks.getInt();
        if (cands.size() > max) {
            cands.sort(Comparator.comparingDouble(Cand::d2));
            cands = cands.subList(0, max);
        }

        String st = style.get();
        boolean filled = !st.equals("Outline"), outline = !st.equals("Filled");
        double t = thickness.getDouble();
        for (Cand c : cands) {
            double fadeMul = fade.get() ? 1.0 - 0.6 * Math.sqrt(c.d2()) / rng : 1.0;
            Found f = c.f();
            if (filled)
                r.filledBox(f.x(), f.y(), f.z(), f.x() + 1, f.y() + 1, f.z() + 1,
                        Renderer.withAlpha(f.color(), (int) (fillOpacity.getInt() * fadeMul)));
            if (outline)
                r.outlineBox(f.x(), f.y(), f.z(), f.x() + 1, f.y() + 1, f.z() + 1, t,
                        Renderer.withAlpha(f.color(), (int) (255 * fadeMul)));
        }
    }
}
