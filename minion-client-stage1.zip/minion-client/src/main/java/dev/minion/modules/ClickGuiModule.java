package dev.minion.modules;

import dev.minion.core.Category;
import dev.minion.core.Module;
import dev.minion.core.setting.BoolSetting;
import dev.minion.core.setting.ColorSetting;
import dev.minion.core.setting.NumberSetting;

/** Holds the ClickGUI's own settings so they save/load like any other module. */
public class ClickGuiModule extends Module {
    public static ClickGuiModule INSTANCE;

    public final ColorSetting accent = add(new ColorSetting("Accent color", "Main highlight color of the GUI.", 0xFFFF69DC));
    public final NumberSetting opacity = add(new NumberSetting("Panel opacity", "How opaque the GUI panel is.", 235, 80, 255, 5));
    public final NumberSetting dim = add(new NumberSetting("Background dim", "How much the game is darkened behind the GUI.", 110, 0, 200, 5));
    public final NumberSetting rowHeight = add(new NumberSetting("Row height", "Height of each list row in pixels.", 18, 14, 26, 1));
    public final NumberSetting spacing = add(new NumberSetting("Spacing", "Gap between rows in pixels.", 2, 0, 8, 1));
    public final BoolSetting animations = add(new BoolSetting("Animations", "Smooth scrolling and expand/collapse.", true));

    public ClickGuiModule() {
        super("ClickGUI", "Appearance settings for this menu.", Category.MISC);
        alwaysOn();
        INSTANCE = this;
    }
}
