package dev.minion;

import dev.minion.config.ConfigManager;
import dev.minion.core.ModuleManager;
import dev.minion.gui.ClickGuiScreen;
import dev.minion.modules.BlockEsp;
import dev.minion.modules.ClickGuiModule;
import dev.minion.render.Renderer;
import dev.minion.modules.SusChunkFinder;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MinionClient implements ClientModInitializer {
    public static final Logger LOG = LoggerFactory.getLogger("MinionClient");
    private static final ModuleManager MODULES = new ModuleManager();

    public static ModuleManager modules() { return MODULES; }

    @Override
    public void onInitializeClient() {
        MODULES.register(new ClickGuiModule());
        MODULES.register(new SusChunkFinder());
        MODULES.register(new BlockEsp());
        Renderer.INSTANCE.init();
        ConfigManager.load();

        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of("minionclient", "main"));
        KeyBinding openGui = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.minionclient.open_gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, category));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openGui.wasPressed()) {
                if (mc.currentScreen == null) mc.setScreen(new ClickGuiScreen());
            }
            MODULES.tick(mc);
        });
        ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> ConfigManager.save());
        LOG.info("Minion Client loaded with {} modules", MODULES.all().size());
    }
}
