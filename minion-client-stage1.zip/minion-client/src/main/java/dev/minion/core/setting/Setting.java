package dev.minion.core.setting;

import com.google.gson.JsonElement;

public abstract class Setting<T> {
    public final String name;
    public final String description;
    public final T def;
    protected T value;

    protected Setting(String name, String description, T def) {
        this.name = name;
        this.description = description;
        this.def = def;
        this.value = def;
    }

    public T get() { return value; }
    public void set(T v) { this.value = v; }
    public void reset() { this.value = def; }

    public abstract JsonElement toJson();

    /** Throws IllegalArgumentException on invalid data; callers catch and keep the old value. */
    public abstract void fromJson(JsonElement e);
}
