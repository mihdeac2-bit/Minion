package dev.minion.core.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class NumberSetting extends Setting<Double> {
    public final double min, max, step;

    public NumberSetting(String name, String description, double def, double min, double max, double step) {
        super(name, description, def);
        this.min = min;
        this.max = max;
        this.step = step;
    }

    @Override
    public void set(Double v) {
        double c = Math.max(min, Math.min(max, v));
        if (step > 0) c = Math.round((c - min) / step) * step + min;
        value = Math.max(min, Math.min(max, c));
    }

    public double getDouble() { return value; }
    public int getInt() { return (int) Math.round(value); }
    public double fraction() { return (value - min) / (max - min); }
    public void setFromFraction(double f) { set(min + Math.max(0, Math.min(1, f)) * (max - min)); }

    @Override public JsonElement toJson() { return new JsonPrimitive(value); }

    @Override
    public void fromJson(JsonElement e) {
        if (e == null || !e.isJsonPrimitive() || !e.getAsJsonPrimitive().isNumber())
            throw new IllegalArgumentException("expected number");
        set(e.getAsDouble());
    }
}
