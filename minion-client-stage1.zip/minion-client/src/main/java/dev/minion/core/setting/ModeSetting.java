package dev.minion.core.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.util.List;

public class ModeSetting extends Setting<String> {
    public final List<String> modes;

    public ModeSetting(String name, String description, String def, String... modes) {
        super(name, description, def);
        this.modes = List.of(modes);
    }

    public void cycle(int dir) {
        int i = modes.indexOf(value);
        i = Math.floorMod(i + dir, modes.size());
        value = modes.get(i);
    }

    @Override public JsonElement toJson() { return new JsonPrimitive(value); }

    @Override
    public void fromJson(JsonElement e) {
        if (e == null || !e.isJsonPrimitive() || !e.getAsJsonPrimitive().isString())
            throw new IllegalArgumentException("expected string");
        String s = e.getAsString();
        if (!modes.contains(s)) throw new IllegalArgumentException("unknown mode " + s);
        value = s;
    }
}
