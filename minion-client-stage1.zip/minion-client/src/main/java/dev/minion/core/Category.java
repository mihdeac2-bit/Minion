package dev.minion.core;

public enum Category {
    COMBAT("Combat", "C"),
    PVP("PvP", "P"),
    VISUALS("Visuals", "V"),
    BASE_FINDING("Base Finding", "B"),
    CHUNK_FINDING("Chunk Finding", "#"),
    PLAYER_ACTIVITY("Player Activity", "A"),
    MOVEMENT("Movement", "M"),
    UTILITY("Utility", "U"),
    HUD("HUD", "H"),
    MISC("Miscellaneous", "*");

    public final String label;
    public final String icon;

    Category(String label, String icon) {
        this.label = label;
        this.icon = icon;
    }
}
