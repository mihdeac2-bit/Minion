package dev.minion.config;

import com.google.gson.*;
import dev.minion.MinionClient;
import dev.minion.core.Module;
import dev.minion.core.setting.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;
import java.util.regex.Pattern;

/** Named profiles stored as JSON under config/minionclient/profiles/. Invalid data never crashes the client. */
public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Pattern VALID_NAME = Pattern.compile("[A-Za-z0-9_-]{1,32}");
    private static final Path DIR = FabricLoader.getInstance().getConfigDir().resolve("minionclient");
    private static final Path PROFILES = DIR.resolve("profiles");
    private static final Path ACTIVE_FILE = DIR.resolve("active.txt");
    private static final int VERSION = 1;

    private static String active = "default";

    private ConfigManager() {}

    public static String active() { return active; }

    public static void load() {
        try {
            Files.createDirectories(PROFILES);
            if (Files.exists(ACTIVE_FILE)) {
                String n = Files.readString(ACTIVE_FILE).trim();
                if (VALID_NAME.matcher(n).matches()) active = n;
            }
            loadProfile(active);
        } catch (Exception e) {
            MinionClient.LOG.error("Failed to load config, using defaults", e);
        }
    }

    public static void save() {
        try {
            Files.createDirectories(PROFILES);
            Path file = profilePath(active);
            Path tmp = file.resolveSibling(active + ".json.tmp");
            Files.writeString(tmp, GSON.toJson(serialize()));
            Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING);
            Files.writeString(ACTIVE_FILE, active);
        } catch (Exception e) {
            MinionClient.LOG.error("Failed to save config", e);
        }
    }

    public static List<String> profiles() {
        TreeSet<String> names = new TreeSet<>();
        names.add(active);
        try {
            if (Files.isDirectory(PROFILES)) {
                try (DirectoryStream<Path> ds = Files.newDirectoryStream(PROFILES, "*.json")) {
                    for (Path p : ds) {
                        String f = p.getFileName().toString();
                        String n = f.substring(0, f.length() - 5);
                        if (VALID_NAME.matcher(n).matches()) names.add(n);
                    }
                }
            }
        } catch (IOException e) {
            MinionClient.LOG.warn("Could not list profiles", e);
        }
        return new ArrayList<>(names);
    }

    public static void switchProfile(String name) {
        if (!VALID_NAME.matcher(name).matches() || name.equals(active)) return;
        save();
        active = name;
        resetAll();
        loadProfile(name);
        try { Files.writeString(ACTIVE_FILE, active); } catch (IOException ignored) {}
    }

    public static void cycleProfile(int dir) {
        List<String> all = profiles();
        int i = Math.floorMod(all.indexOf(active) + dir, all.size());
        switchProfile(all.get(i));
    }

    /** Creates a new profile from the current state and switches to it. Returns its name. */
    public static String createProfile() {
        save();
        List<String> existing = profiles();
        int n = 1;
        while (existing.contains("profile" + n)) n++;
        active = "profile" + n;
        save();
        return active;
    }

    private static Path profilePath(String name) { return PROFILES.resolve(name + ".json"); }

    private static void resetAll() {
        for (Module m : MinionClient.modules().all()) m.resetToDefaults();
    }

    private static JsonObject serialize() {
        JsonObject root = new JsonObject();
        root.addProperty("version", VERSION);
        JsonObject mods = new JsonObject();
        for (Module m : MinionClient.modules().all()) {
            JsonObject mo = new JsonObject();
            if (m.isToggleable()) mo.addProperty("enabled", m.isEnabled());
            mo.addProperty("key", m.getKey());
            JsonObject so = new JsonObject();
            for (Setting<?> s : m.getSettings()) so.add(s.name, s.toJson());
            mo.add("settings", so);
            mods.add(m.name, mo);
        }
        root.add("modules", mods);
        return root;
    }

    private static void loadProfile(String name) {
        Path file = profilePath(name);
        if (!Files.exists(file)) return;
        JsonObject root;
        try {
            root = JsonParser.parseString(Files.readString(file)).getAsJsonObject();
        } catch (Exception e) {
            MinionClient.LOG.error("Profile {} is corrupt; moved aside and using defaults", name, e);
            try {
                Files.move(file, file.resolveSibling(name + ".json.bad"), StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException ignored) {}
            return;
        }
        JsonObject mods = root.has("modules") && root.get("modules").isJsonObject()
                ? root.getAsJsonObject("modules") : new JsonObject();
        for (Module m : MinionClient.modules().all()) {
            try {
                if (!mods.has(m.name) || !mods.get(m.name).isJsonObject()) continue;
                JsonObject mo = mods.getAsJsonObject(m.name);
                if (mo.has("key") && mo.get("key").isJsonPrimitive() && mo.get("key").getAsJsonPrimitive().isNumber())
                    m.setKey(mo.get("key").getAsInt());
                if (mo.has("settings") && mo.get("settings").isJsonObject()) {
                    JsonObject so = mo.getAsJsonObject("settings");
                    for (Setting<?> s : m.getSettings()) {
                        if (!so.has(s.name)) continue;
                        try {
                            s.fromJson(so.get(s.name));
                        } catch (Exception e) {
                            MinionClient.LOG.warn("Ignoring invalid setting {}.{}: {}", m.name, s.name, e.getMessage());
                        }
                    }
                }
                if (m.isToggleable() && mo.has("enabled") && mo.get("enabled").isJsonPrimitive()
                        && mo.get("enabled").getAsJsonPrimitive().isBoolean())
                    m.setEnabled(mo.get("enabled").getAsBoolean());
            } catch (Exception e) {
                MinionClient.LOG.warn("Ignoring invalid config for module {}", m.name, e);
            }
        }
    }
}
